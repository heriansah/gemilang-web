$(function () {

  $('#submit_order').on( "click", function(e) {

    e.preventDefault();
    $.ajax({
      url: $('.mainurl').val() +'/cek_order',
      cache: false,
      success:function(data)
      {
        var data = $.parseJSON(data);

        if(data){
          if (confirm("Anda sedang melakukan order sebelumnya, anda yakin ingin menghapus orderan sebelumnya?")) {

            $.ajax({
              url: $('.mainurl').val() +'/remove_order/',
              cache: false,
              success:function(data){
                window.location.reload();
                $( "#form_order" ).submit();
              }
            });

          } else {
              alert('Anda akan diarahkan ke pemesanan sebelumnya');
              window.location.href = $('.mainurl').val() +'/reservation';
          }
        }
          // var data = $.parseJSON(data);

          // $('.modal-body').empty();
          // $('.modal-body').append(data[0]);
          // $('#largeModalLabel').text(data[1]);
          // $('.save').attr('id', data[2]);
          // $('#cd_agree').val(code_agree);
      }
    });
    
  });

});

