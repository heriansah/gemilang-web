$(function () {

    $('.js-exportable-ajax').on('click', '.edit-marketing', function (event) {
        var code_tab = table.row( $(this).parent().parent() ).data()[0];
        var cek_follow_up = 'N';
        
        event.stopPropagation();
        event.preventDefault();
        $.ajax({
            url: $('.mainurl').val() +'/marketing/cek_follow_up/'+code_tab,
            type: "GET",
            cache: false,
            success:function(data)
            {
                var data = $.parseJSON(data);
                if(data == 'N'){
                    if (confirm("Anda yakin akan memulai untuk follow up customer ini? (waktu mulai mem-follow-up akan disimpan)")) {

                        $.ajax({
                            url: $('.mainurl').val() +'/marketing/getmodalentry/assign/'+code_tab,
                            type: "GET",
                            cache: false,
                            success:function(data)
                            {
                                var data = $.parseJSON(data);
                
                                $('.modal-body-assign').empty();
                                $('.modal-body-assign').append(data[0]);
                                $('#largeModalLabel-assign').text(data[1]);
                                $('.save-assign').attr('id', data[2]);
                                $('#largeModal').modal('show');

                            }
                        });
                        
                        // $.ajax({
                        //     url: $('.mainurl').val() +'/marketing/getmodalentry/assign/'+code_tab,
                        //     type: "GET",
                        //     cache: false,
                        //     success:function(data)
                        //     {
                        //         var data = $.parseJSON(data);
                
                        //         $('.modal-body-assign').empty();
                        //         $('.modal-body-assign').append(data[0]);
                        //         $('#largeModalLabel-assign').text(data[1]);
                        //         $('.save-assign').attr('id', data[2]);
                        //         $('#largeModal').modal('show');

                        //     }
                        // });
                    } else {

                        event.stopPropagation();
                        event.preventDefault();
                    } 
                }else{
                    $.ajax({
                        url: $('.mainurl').val() +'/marketing/getmodalentry/assign/'+code_tab,
                        type: "GET",
                        cache: false,
                        success:function(data)
                        {
                            var data = $.parseJSON(data);
            
                            $('.modal-body-assign').empty();
                            $('.modal-body-assign').append(data[0]);
                            $('#largeModalLabel-assign').text(data[1]);
                            $('.save-assign').attr('id', data[2]);
                            $('#largeModal').modal('show');

                        }
                    });
                }
            }
        });
    });

    $('.js-exportable-ajax').on('click', '.payment-marketing', function (event) {
        var code_tab = table.row( $(this).parent().parent() ).data()[0];
        var cek_follow_up = 'N';
        
        event.stopPropagation();
        event.preventDefault();
        $.ajax({
            url: $('.mainurl').val() +'/marketing/cek_payment/'+code_tab,
            type: "GET",
            cache: false,
            success:function(data)
            {
                var data = $.parseJSON(data);
                if(data){

                    $.ajax({
                        url: $('.mainurl').val() +'/marketing/getmodalentry/payment/'+code_tab,
                        type: "GET",
                        cache: false,
                        success:function(data)
                        {
                            var data = $.parseJSON(data);
            
                            $('.modal-body-payment').empty();
                            $('.modal-body-payment').append(data[0]);
                            $('#largeModalLabel-payment').text(data[1]);
                            $('.save-payment').attr('id', data[2]);
                            $('#largeModalPayment').modal('show');

                        }
                    });
                    
                    
                    
                }else{

                    alert('Lakukan validasi data terlebih dahulu!');
                }
            }
        });
    });



    $("#followup").change(function () {

        if(!$("#followup[type='checkbox']").is(":checked")){
            $("#paid").prop('checked', false);
        }
        $('.js-exportable-ajax').DataTable().clear().destroy();
        $.tables_js_exportable_ajax();
    });
    $("#paid").change(function () {
        if($("#paid[type='checkbox']").is(":checked")){
            $("#followup").prop('checked', true);
        }
        $('.js-exportable-ajax').DataTable().clear().destroy();
        $.tables_js_exportable_ajax();
    });
    $("#refresh").click(function () {

        $('.js-exportable-ajax').DataTable().clear().destroy();
        $.tables_js_exportable_ajax();
    });

    $('#largeModal').on('click', '.form-assign', function (event) {
        $(this).prop('readonly', false);
    });
    
    $('#largeModal').on('click', '#cek_harga', function (event) {
        alert('Data payment berhasil diload');
        var stateID = $(this).val();

        var product_cat = $('.form-assign[name=product_category]  option:selected').val();
        var product = $('.form-assign[name=product] option:selected').val();
        var bpartner = $('.form-assign[name=bpartner] option:selected').val(); 
        var kuota = $('.form-assign[name=kuota]').val();

        if(product_cat!= "" &&  product != "" && bpartner != "" && kuota != ""){

            if($.isNumeric(kuota)){
                $.ajax({
                    url: '/checkPriceAndDiscount/'+product+'/'+kuota+'/'+bpartner,
                    type: "GET",
                    dataType: "json",
                    cache: false,
                    success:function(data)
                    {
                        console.log(data);
                        $('#price').text(data['pricelist']);
                        $('#totalall').text(data['totalall']);
                        $('#kuota').text(kuota);
                        $('#discount').text(data['discount'] + ' %');
                        $('#subtotal').text(data['subtotal']);

                    }
                });
                if($('#type-pengunjung').val() == "Rombongan"){
                    var type = $("#type-pengunjung option:selected").val() + ' - ' + $("#type-rombongan option:selected").text();
                }else{
                    var type = $("#type-pengunjung option:selected").val();
                }
                $('#type').text(type);
                $('#activity').text($("#categories-form option:selected").text() +' - '+ $("#products-form option:selected").text());
                $('#quantity').text($("#kuota").val());
            }else{

                event.stopPropagation();
                event.preventDefault();
                alert('Kuota hanya diisi angka!');
                }
        }else{
            event.stopPropagation();
            event.preventDefault();
            alert('Data harus diisi semua terlebih dahulu!');
        }
    });
    


    $("#categories-form-new").on('change', function() {

        var stateID = $(this).val();
        if(stateID){
            $.ajax({
                url: '/productCategories/'+stateID,
                type: "GET",
                dataType: "json",
                cache: false,
                success:function(data)
                {

                    console.log(data);
                    $('#products-form-new').empty();
                    $('#products-form-new').append('<option disabled selected>-- Pilih Kegiatan --</option>');
                    $.each(data, function( value, key) {
                        $('#products-form-new').append('<option value="'+ key +'">'+ value.toLowerCase().split(' ').map((s) => s.charAt(0).toUpperCase() + s.substring(1)).join(' ') +'</option>');
                    });
                    $('#products-form-new').selectpicker('refresh');
                }
            });
        }else
        {
            $('#products-form-new').empty();
        }
    });
            
    $('#largeModalNew').on('click', '#cek_harga_new', function (event) {
        alert('Data payment berhasil diload');
        var stateID = $(this).val();

        var product_cat = $('.form-assign-new[name=product_category]  option:selected').val();
        var product = $('.form-assign-new[name=product] option:selected').val();
        var bpartner = $('.form-assign-new[name=bpartner] option:selected').val(); 
        var kuota = $('.form-assign-new[name=kuota]').val();

        if(product_cat!= "" &&  product != "" && bpartner != "" && kuota != ""){

            if($.isNumeric(kuota)){
                $.ajax({
                    url: '/checkPriceAndDiscount/'+product+'/'+kuota+'/'+bpartner,
                    type: "GET",
                    dataType: "json",
                    cache: false,
                    success:function(data)
                    {
                        console.log(data);
                        $('#price-new').text(data['pricelist']);
                        $('#totalall-new').text(data['totalall']);
                        $('#kuota-new').text(kuota);
                        $('#discount-new').text(data['discount'] + ' %');
                        $('#subtotal-new').text(data['subtotal']);

                    }
                });
            }else{

                event.stopPropagation();
                event.preventDefault();
                alert('Kuota hanya diisi angka!');
                }
        }else{
            event.stopPropagation();
            event.preventDefault();
            alert('Data harus diisi semua terlebih dahulu!');
        }
    });
                    

});

