$(function () {

        $('.js-exportable-ajax').on('click', '.modal-task-marketing', function () {
            var code_tab = table.row( $(this).parent().parent() ).data()[0];
    
            $.ajax({
                url: $('.mainurl').val() +'/manager/task_manager/getmodalentry/'+code_tab,
                type: "GET",
                cache: false,
                success:function(data)
                {
                    var data = $.parseJSON(data);
    
                    $('.modal-body').empty();
                    $('.modal-body').append(data[0]);
                    $('#largeModalLabel').text(data[1]);
                    $('.save').attr('id', data[2]);
                }
            });
        });


        $("#current").change(function () {

            $('.js-exportable-ajax').DataTable().clear().destroy();
            $.tables_js_exportable_ajax();
        });
        $("#refresh").click(function () {
    
            $('.js-exportable-ajax').DataTable().clear().destroy();
            $.tables_js_exportable_ajax();
        });

});

